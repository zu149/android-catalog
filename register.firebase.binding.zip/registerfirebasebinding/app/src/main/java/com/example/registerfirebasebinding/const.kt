package com.example.registerfirebasebinding

lateinit var Main: MenuActivity