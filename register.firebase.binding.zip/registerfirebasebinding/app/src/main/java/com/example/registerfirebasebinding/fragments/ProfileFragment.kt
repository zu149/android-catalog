package com.example.registerfirebasebinding.fragments

import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.view.*
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil.setContentView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.bumptech.glide.load.ImageHeaderParser
import com.example.registerfirebasebinding.GlideLoader
import com.example.registerfirebasebinding.Main
import com.example.registerfirebasebinding.R
import com.example.registerfirebasebinding.databinding.ActivityMainBinding
import com.example.registerfirebasebinding.databinding.FragmentDetailsBinding
import com.example.registerfirebasebinding.databinding.FragmentProfileBinding
import com.example.registerfirebasebinding.users
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.auth.User


class ProfileFragment : Fragment() {

    private var fragmentBinding: FragmentProfileBinding? = null
    private val mBinding get() = fragmentBinding!!


    private var imageFileUri: Uri? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val binding = FragmentProfileBinding.bind(view) // запрет изменения пофиля
        fragmentBinding = binding
        binding.name.isEnabled = false
        binding.email.isEnabled = false
        binding.phone.isEnabled = false
        binding.img.isEnabled = false



        FirebaseFirestore.getInstance().collection("users") // чтение объекта (юзера)
            .document(getCurrntUserId())
            .get()
            .addOnSuccessListener { document ->
                val user = document.toObject(users::class.java) // заполнение
                if (user != null) {
                    binding.nameText.text = user.name.toEditable()

                    GlideLoader(requireActivity(),1).loadUserProfile(user.img, binding.profilePhoto) // загрузка фоткв
                }

            }

        val email = FirebaseAuth.getInstance().currentUser?.email.toString() // путь к емаилу в базе
        binding.emailText.text = email.toEditable() // подтягивание емаила из регистрации в профиль

    }


    private fun getCurrntUserId(): String { // ПОЛУЧЕНИЕ ID ЮЗЕРА
        val currentUser = FirebaseAuth.getInstance().currentUser
        var currentUserId = ""
        if (currentUser != null) {
            currentUserId = currentUser.uid
        }
        return currentUserId
    }



    fun String.toEditable(): Editable =  Editable.Factory.getInstance().newEditable(this) // помещаем емаил в едит текст


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        fragmentBinding  = FragmentProfileBinding.inflate(inflater, container, false)
        return mBinding.root
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {


        when(item.itemId) {
            R.id.back_item -> {
                Main.navController.navigate(R.id.profile_to_list)
                return true

            }
            R.id.edit_item -> {
                edit()

                return true

            }
        }

        return super.onOptionsItemSelected(item)
    }


    fun edit() { // изменение прфиля
        mBinding.name.isEnabled = true
        mBinding.phone.isEnabled = true
        mBinding.img.isEnabled = true

        mBinding.hidenButton.isVisible = true

        mBinding.profilePhoto.setOnClickListener{
            GlideLoader(requireActivity(),1).phoneStorageImg(requireActivity())
        }

        mBinding.hidenButton.setOnClickListener { // добавление объекта (юзера) в базу данных
            GlideLoader(requireActivity(),1).uploadImageStorage(requireActivity())

            val userid = FirebaseAuth.getInstance().currentUser?.uid.toString() // получение id
            val email = FirebaseAuth.getInstance().currentUser?.email.toString()
            val name = mBinding.nameText.text.toString()
            val phone = mBinding.phoneText.text.toString()
            val user = users(userid, email, name, phone)
            if (user != null) {
                FirebaseFirestore.getInstance().collection("users")
                    .document(user.id)
                    .set(user, SetOptions.merge()) // объединение данных в колекции
                    .addOnSuccessListener {
                        Main.navController.navigate(R.id.profile_to_list)
                    }.addOnFailureListener {

                    }
            }
        }
    }


    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.profile_menu,menu)
        super.onCreateOptionsMenu(menu, inflater)
    }




}


