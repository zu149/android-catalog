package com.example.registerfirebasebinding.fragments

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.registerfirebasebinding.R
import com.example.registerfirebasebinding.apps
import com.example.registerfirebasebinding.databinding.ActivityMain2Binding
import com.example.registerfirebasebinding.databinding.ActivityMainBinding
import com.example.registerfirebasebinding.databinding.FragmentDetailsBinding
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage


class DetailsFragment : Fragment() {

    private var _binding: FragmentDetailsBinding? = null
    private val binding get() = _binding!!

    private var myid: Int = 0

//    private lateinit var binding: FragmentDetailsBinding

    private val img1: ImageView?
        get() = view?.findViewById(R.id.imageView_one)

    private val title1: TextView?
        get() = view?.findViewById(R.id.one_title)

    private val info1: TextView?
        get() = view?.findViewById(R.id.one_info)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) { // сюда пишутся все действия с компонентами
//        super.onViewCreated(view, savedInstanceState)
//
//        FirebaseFirestore.getInstance().collection("apps").document("one").get()
//            .addOnSuccessListener {
//                val data = it.toObject(Details::class.java)
//                title1!!.text = data?.title
//                info1!!.text = data?.info
//            }
//        binding.skachka!!.setOnClickListener {
//            val storegeApk = Firebase.storage.reference
//            storegeApk.child("apk/file.apk").downloadUrl.addOnSuccessListener {
//                val myFile = DownloadManager.Request(Uri.parse(it.toString()))
//                myFile.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE) // загрузка через файфай или моб интернет
//                myFile.setTitle("file")
//                myFile.setMimeType("application/vnd.android.package-archive")
//                myFile.setDescription("скачивание файла")
//                myFile.allowScanningByMediaScanner() // сканирование файла
//                myFile.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED) // вывод сообщение о завершение скачки
//                myFile.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "myFile") // добавление в загрузки
//                val manager = requireActivity().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager // позволяет скачать фаил
//                manager.enqueue(myFile) // завершение скачивания
//            }
//        }
//    }


    fun setDetail(id: Int) {
            myid = id
            val storegeImg = Firebase.storage.reference // путь к хранилищу
            when (id) {
                R.id.one -> {
                    FirebaseFirestore.getInstance().collection("apps").document("one").get()
                        .addOnSuccessListener {
                            val data = it.toObject(Details::class.java)
                            title1!!.text = data?.title
                            info1!!.text = data?.info
                        }
                    storegeImg.child("img/one.jpeg").downloadUrl.addOnSuccessListener { // скачка фото
                        Glide.with(img1!!).load(it) // загрузка изображения в imageview
                            .centerCrop() // маштабирование
                            .into(img1!!) //загрузка фотки в imageview
                    }
                    binding.skachka!!.setOnClickListener {
                        val storegeApk = Firebase.storage.reference
                        storegeApk.child("apk/file.apk").downloadUrl.addOnSuccessListener {
                            val myFile = DownloadManager.Request(Uri.parse(it.toString()))
                            myFile.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE) // загрузка через файфай или моб интернет
                            myFile.setTitle("file")
                            myFile.setMimeType("application/vnd.android.package-archive")
                            myFile.setDescription("скачивание файла")
                            myFile.allowScanningByMediaScanner() // сканирование файла
                            myFile.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED) // вывод сообщение о завершение скачки
                            myFile.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "myFile.apk") // добавление в загрузки
                            val manager = requireActivity().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager // позволяет скачать фаил
                            manager.enqueue(myFile) // завершение скачивания
                        }
                    }
                }
                R.id.two -> {
                    FirebaseFirestore.getInstance().collection("apps").document("two").get()
                        .addOnSuccessListener {
                            val data = it.toObject(Details::class.java)
                            title1!!.text = data?.title
                            info1!!.text = data?.info
                        }
                    storegeImg.child("img/two.jpeg").downloadUrl.addOnSuccessListener { // скачка фото
                        Glide.with(img1!!).load(it) // загрузка изображения в imageview
                            .centerCrop() // маштабирование
                            .into(img1!!) //загрузка фотки в imageview
                    }
                    binding.skachka!!.setOnClickListener {
                        val storegeApk = Firebase.storage.reference
                        storegeApk.child("apk/file.apk").downloadUrl.addOnSuccessListener {
                            val myFile = DownloadManager.Request(Uri.parse(it.toString()))
                            myFile.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE) // загрузка через файфай или моб интернет
                            myFile.setTitle("file")
                            myFile.setMimeType("application/vnd.android.package-archive")
                            myFile.setDescription("скачивание файла")
                            myFile.allowScanningByMediaScanner() // сканирование файла
                            myFile.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED) // вывод сообщение о завершение скачки
                            myFile.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "myFile.apk") // добавление в загрузки
                            val manager = requireActivity().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager // позволяет скачать фаил
                            manager.enqueue(myFile) // завершение скачивания
                        }
                    }
                }
                R.id.three -> {
                    FirebaseFirestore.getInstance().collection("apps").document("three").get()
                        .addOnSuccessListener {
                            val data = it.toObject(Details::class.java)
                            title1!!.text = data?.title
                            info1!!.text = data?.info
                        }
                    storegeImg.child("img/three.jpg").downloadUrl.addOnSuccessListener { // скачка фото
                        Glide.with(img1!!).load(it) // загрузка изображения в imageview
                            .centerCrop() // маштабирование
                            .into(img1!!) //загрузка фотки в imageview
                    }
                    binding.skachka!!.setOnClickListener {
                        val storegeApk = Firebase.storage.reference
                        storegeApk.child("apk/file.apk").downloadUrl.addOnSuccessListener {
                            val myFile = DownloadManager.Request(Uri.parse(it.toString()))
                            myFile.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE) // загрузка через файфай или моб интернет
                            myFile.setTitle("file")
                            myFile.setMimeType("application/vnd.android.package-archive")
                            myFile.setDescription("скачивание файла")
                            myFile.allowScanningByMediaScanner() // сканирование файла
                            myFile.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED) // вывод сообщение о завершение скачки
                            myFile.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "myFile.apk") // добавление в загрузки
                            val manager = requireActivity().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager // позволяет скачать фаил
                            manager.enqueue(myFile) // завершение скачивания
                        }
                    }
                }
                R.id.four -> {
                    FirebaseFirestore.getInstance().collection("apps").document("four").get()
                        .addOnSuccessListener {
                            val data = it.toObject(Details::class.java)
                            title1!!.text = data?.title
                            info1!!.text = data?.info
                        }
                    storegeImg.child("img/four.jpg").downloadUrl.addOnSuccessListener { // скачка фото
                        Glide.with(img1!!).load(it) // загрузка изображения в imageview
                            .centerCrop() // маштабирование
                            .into(img1!!) //загрузка фотки в imageview
                    }
                    binding.skachka!!.setOnClickListener {
                        val storegeApk = Firebase.storage.reference
                        storegeApk.child("apk/file.apk").downloadUrl.addOnSuccessListener {
                            val myFile = DownloadManager.Request(Uri.parse(it.toString()))
                            myFile.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE) // загрузка через файфай или моб интернет
                            myFile.setTitle("file")
                            myFile.setMimeType("application/vnd.android.package-archive")
                            myFile.setDescription("скачивание файла")
                            myFile.allowScanningByMediaScanner() // сканирование файла
                            myFile.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED) // вывод сообщение о завершение скачки
                            myFile.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "myFile.apk") // добавление в загрузки
                            val manager = requireActivity().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager // позволяет скачать фаил
                            manager.enqueue(myFile) // завершение скачивания
                        }
                    }
                }
                R.id.five -> {
                    FirebaseFirestore.getInstance().collection("apps").document("five").get()
                        .addOnSuccessListener {
                            val data = it.toObject(Details::class.java)
                            title1!!.text = data?.title
                            info1!!.text = data?.info
                        }
                    storegeImg.child("img/five.jpg").downloadUrl.addOnSuccessListener { // скачка фото
                        Glide.with(img1!!).load(it) // загрузка изображения в imageview
                            .centerCrop() // маштабирование
                            .into(img1!!) //загрузка фотки в imageview
                    }
                    binding.skachka!!.setOnClickListener {
                        val storegeApk = Firebase.storage.reference
                        storegeApk.child("apk/file.apk").downloadUrl.addOnSuccessListener {
                            val myFile = DownloadManager.Request(Uri.parse(it.toString()))
                            myFile.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE) // загрузка через файфай или моб интернет
                            myFile.setTitle("file")
                            myFile.setMimeType("application/vnd.android.package-archive")
                            myFile.setDescription("скачивание файла")
                            myFile.allowScanningByMediaScanner() // сканирование файла
                            myFile.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED) // вывод сообщение о завершение скачки
                            myFile.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "myFile.apk") // добавление в загрузки
                            val manager = requireActivity().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager // позволяет скачать фаил
                            manager.enqueue(myFile) // завершение скачивания
                        }
                    }
                }
            }




    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        return root
    }
}


