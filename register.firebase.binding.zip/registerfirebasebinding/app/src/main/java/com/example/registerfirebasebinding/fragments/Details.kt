package com.example.registerfirebasebinding.fragments

data class Details(
    val title: String = "",
    val info: String = "",
)
