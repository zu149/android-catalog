package com.example.registerfirebasebinding

data class users (
    val id: String = "",
    val email: String = "",
    val name: String = "",
    val phone: String = "",
    val img: String = ""



    )
