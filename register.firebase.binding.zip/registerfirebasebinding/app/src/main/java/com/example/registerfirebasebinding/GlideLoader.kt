package com.example.registerfirebasebinding

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.google.android.gms.common.internal.Constants
import com.google.common.io.Files.getFileExtension
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.IOException
import androidx.appcompat.app.AppCompatActivity
import com.example.registerfirebasebinding.databinding.FragmentProfileBinding


class GlideLoader (val context: Context, contentLayoutId: Int) :
    AppCompatActivity(contentLayoutId) { // ссылка посылается сюда

    private var fragmentBinding: FragmentProfileBinding? = null
    private val binding get() = fragmentBinding!!

    val PICK_IMAGE_REQUEST_CODE = 1
    private var imageFileUri: Uri? = null
    var imageType ="imageType"

    fun loadUserProfile(image: Any, imageView: ImageView) {
        try {
            Glide // изображение загружается по ссылке в имэдж вью
                .with(context)
                .load(image)
                .centerCrop()
                .placeholder(R.drawable.ic_baseline_person_24)
                .into(imageView) //загрузка в imageView
        }catch (e : IOException) {
            e.printStackTrace() //отображение ошибки
        }
    }

    fun phoneStorageImg (activity: Activity) { // заход в файлы телефона
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST_CODE)
    }
    fun getFileExtension(activity: Activity, uri: Uri?) : String? { // для получение типа фотки
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(activity.contentResolver.getType(uri!!))
    }

    fun uploadImageStorage (activity: Activity) {
        val imgStore : StorageReference = FirebaseStorage.getInstance().reference.child(
            imageType
                    + System.currentTimeMillis() + "."
                    + getFileExtension(activity, imageFileUri)
        )
        imgStore.putFile(imageFileUri!!)
            .addOnSuccessListener {

            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { // полуаем сыылку на фото в памяти телефона
        if (resultCode == Activity.RESULT_OK && requestCode == PICK_IMAGE_REQUEST_CODE) {
            if (data != null) {
                imageFileUri = data.data
                loadUserProfile(data.data!!, binding.profilePhoto)
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

}