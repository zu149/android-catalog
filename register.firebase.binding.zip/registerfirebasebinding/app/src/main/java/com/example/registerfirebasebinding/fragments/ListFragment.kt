package com.example.registerfirebasebinding.fragments

import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.registerfirebasebinding.Main
import com.example.registerfirebasebinding.R
import com.example.registerfirebasebinding.applistner
import com.example.registerfirebasebinding.apps
import com.google.android.material.appbar.MaterialToolbar
import com.google.firebase.firestore.FirebaseFirestore


@Suppress("DEPRECATION")
class ListFragment : Fragment(), View.OnClickListener {

    private val one: TextView?
    get() = view?.findViewById(R.id.one)

    private val two: TextView?
        get() = view?.findViewById(R.id.two)

    private val three: TextView?
        get() = view?.findViewById(R.id.three)

    private val four: TextView?
        get() = view?.findViewById(R.id.four)

    private val five: TextView?
        get() = view?.findViewById(R.id.five)

    private lateinit var filmListener: applistner

    lateinit private var toolbar: MaterialToolbar

    override fun onAttach(context: Context) { // задйствуется интерфейс
        super.onAttach(context)
        if (context is applistner) {
            filmListener = context
        } else {
            throw RuntimeException("выберите фильм")
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.list_menu,menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) { // для взаимодействия с компонентами
        super.onViewCreated(view, savedInstanceState)
        var list = listOf<View>(
            view.findViewById(R.id.one),
            view.findViewById(R.id.two),
            view.findViewById(R.id.three),
            view.findViewById(R.id.four),
            view.findViewById(R.id.five),
        )
        list.forEach { //добавления обработчика событий для каждого вью
            it.setOnClickListener(this)
        }

        FirebaseFirestore.getInstance().collection("apps").document("document").get()
            .addOnSuccessListener { //обращение к колlекции
                val data = it.toObject(apps::class.java)
//            val txt = v.findViewById<TextView>(R.id.one)
                one!!.text = data?.one
                two!!.text = data?.two
                three!!.text = data?.three
                four!!.text = data?.four
                five!!.text = data?.five
            }


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.profile_item -> {
                Main.navController.navigate(R.id.list_to_profile)
                return true

            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)

    }





    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_list, container, false)
    }

    override fun onClick(v: View?) {
        v?.let {
            filmListener.appselected(it.id) //it заменяется на айди элемента из списка
        }
    }


}