package com.example.registerfirebasebinding

data class apps(
    val one: String = "",
    val two: String = "",
    val three: String = "",
    val four: String = "",
    val five: String = "",
)
