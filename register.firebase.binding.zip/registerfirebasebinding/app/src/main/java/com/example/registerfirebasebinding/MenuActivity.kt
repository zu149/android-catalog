package com.example.registerfirebasebinding

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.widget.Toolbar
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.example.registerfirebasebinding.databinding.ActivityMenuBinding
import com.example.registerfirebasebinding.fragments.DetailsFragment
import com.example.registerfirebasebinding.fragments.ProfileFragment
import com.google.android.material.appbar.MaterialToolbar

const val appid = "appid"
interface applistner {
    fun appselected(id: Int)
}

class MenuActivity : AppCompatActivity(), applistner {
    lateinit var binding: ActivityMenuBinding
 //   lateinit var toolbar: MaterialToolbar
 lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)
       navController = Navigation.findNavController(this, R.id.fragment_list)
        Main = this
//        setUpActionBar()

        //     toolbar = binding.toolbar
    //   setSupportActionBar(toolbar)

    }

    override fun appselected(id: Int) {
        val intent = Intent (this@MenuActivity, DetailsActivity::class.java)
        intent.putExtra(appid, id) // отправка айди элемента из списка
        startActivity(intent)

    }


//private fun setUpActionBar(){
//    setSupportActionBar(binding.toolbarMenu)
//
//    supportActionBar?.setDisplayHomeAsUpEnabled(true)
//    supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_baseline_arrow_back_24)
//    binding.toolbarMenu.setNavigationOnClickListener {
//        onBackPressed()
//    }

}
